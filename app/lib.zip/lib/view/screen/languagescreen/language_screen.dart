

import 'package:app/helper/theme/color.dart';
import 'package:app/view/widget/appbar.dart';
import 'package:app/view/widget/customButton.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../helper/theme/text_theme.dart';

class LanguageScreen extends StatelessWidget {
  const LanguageScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return  Scaffold(

      appBar: CusAppBar(context, "تغير اللغة".tr,show: true ),

      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(

          children: [
        RadioListTile(

          activeColor: LightColor.primary,
        title: Text('العريية'.tr,style: AppTextStyleTheme.appParTxtBld,),
        value: 0,
        groupValue: 0,
        onChanged: (value) {

        },
      ),     RadioListTile(
              activeColor: LightColor.primary,
        title: Text('English',style: AppTextStyleTheme.appParTxtBld,),
        value: 1,
        groupValue: 0,
        onChanged: (value) {

        },
      ),     RadioListTile(
              activeColor: LightColor.primary,
        title: Text('Urdu'.tr,style: AppTextStyleTheme.appParTxtBld,),
        value: 1,
        groupValue: 0,
        onChanged: (value) {

        },
      ),
 SizedBox(height: 30,),

            CustomButton(text: "تغير",)
          ],
        ),
      ),

    );
  }
}
