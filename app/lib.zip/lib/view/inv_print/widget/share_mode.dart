// enum ShareMode { view, extract, share, print }
