
import 'package:country_flags/country_flags.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../helper/core/language/controller/app_language.dart';
import '../../helper/theme/text_theme.dart';


class LanguageWidget extends StatelessWidget {
  const LanguageWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      physics: BouncingScrollPhysics(),
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(10.0),
          child:GetBuilder<AppLanguageController>(
           // init:AppLanguageController() ,
            builder: (controller) => Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [


              SizedBox(
                height: 10,
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    SizedBox(width: 20,),
                    Text(
                        "Language".tr,
                        style: AppTextStyleTheme.appParTxtBld.copyWith(color: Get.theme.hoverColor)  ),

                    Padding(
                      padding: const EdgeInsets.all(4.0),
                      child: GestureDetector(
                          onTap: () {
                            Get.back();
                          },
                          child: CircleAvatar(backgroundColor: Get.theme.highlightColor,radius: 12,child: Icon(Icons.clear,size: 20,color:Get.theme.cardColor))),
                    ),
                  ],
                ),
              ),
              SizedBox(
                height: 10,
              ),

                InkWell(onTap: () {
controller.onClickRadio(0);
                },
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 10),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            CountryFlag.fromCountryCode(
                              'sa',
                              height: 30,
                              width: 50,
                              borderRadius: 8,
                            ),
                            SizedBox(width: 10,),
                            Text("عربي",style: AppTextStyleTheme.appParTxtBld.copyWith(color: context.theme.hoverColor),),


                          ],
                        ),

                        Radio(activeColor: Get.theme.hoverColor,value: 0, groupValue:controller.value, onChanged: (value) {
                          controller.onClickRadio(0);
                        },)

                      ],
                    ),
                  ),
                ),
               SizedBox(height: 4,),
                Divider(color: Get.theme.hintColor),
                SizedBox(height: 4,),
                InkWell(
                  onTap: () {
                    controller.onClickRadio(1);
                  },
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 10),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            CountryFlag.fromCountryCode(
                              'us',
                              height: 30,
                              width: 50,
                              borderRadius: 8,
                            ),
                            SizedBox(width: 10,),
                            Text("English",style: AppTextStyleTheme.appParTxtBld.copyWith(color: context.theme.hoverColor),),


                          ],
                        ),

                        Radio(activeColor:Get.theme.hoverColor,value: 1, groupValue: controller.value, onChanged: (value) {
                          controller.onClickRadio(1);
                        },)

                      ],
                    ),
                  ),
                ),


            ],),
          ),
        ),
      ),
    );
  }
}
