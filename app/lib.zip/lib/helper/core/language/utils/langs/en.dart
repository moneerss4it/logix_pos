const Map<String, String> en = {

  'Sign in':'Sign in',
  'Sign out': 'Sign out',
  'Username':'Username',

  'Do you want to logout':"Do you want to logout?",

  'Password':'Password',

  'Choose':'Choose',
  'Enter the Password' :'Enter the Password',
  'Enter the Username' :'Enter the Username',
  "Next":"Next",
  'Enter the ID member':'Enter the ID member',

  "Home":"Home",
  'Cancel':'Cancel',
  'Confirm':'Confirm',


  "From date":"From date",
  "To date":"To date",

  "Welcome":  'Welcome',
  "Forgot Your Password?":  "Forgot Your Password?",
};
