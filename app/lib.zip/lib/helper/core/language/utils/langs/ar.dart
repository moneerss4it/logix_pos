const Map<String, String> ar = {

  'Sign in':'تسجيل الدخول',
  'Sign out':'تسجيل الخروج',
  'Username':'اسم المستخدم',
  'Do you want to logout':"هل تريد تسجيل الخروج؟",

  'Password':'كلمة المرور',

  'Choose':'اختر',
  'Enter the Password' :'ادخل كلمة المرور',
  'Enter the Username' :'ادخل اسم المستخدم',
  "Next":"التالي",
  'Enter the ID member':'ادخل رقم العضوية',

  "Home":"الرئيسية",
  'Cancel':'الغاء',
  'Confirm':'تأكيد',

  "Search":"بحث",

  "ID Member":"رقم العضوية",



  "From date":"من تاريخ",
  "To date":"إلى تاريخ",

  "Welcome":  'أهلا بك',
  "Forgot Your Password?":  "هل نسيت كلمة المرور ؟",



};
