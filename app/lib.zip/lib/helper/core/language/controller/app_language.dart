
import 'package:app/helper/utill/app_constants.dart';
import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

import '../utils/local_storage/local_storgae.dart';

class AppLanguageController extends GetxController  implements GetxService {
  var appLocale=''.obs ;
  int value=0;
  @override
  void onInit() async {
    // TODO: implement onInit
    super.onInit();

    LocalStorage localStorage = LocalStorage();
    appLocale.value = await localStorage.languageSelected
        == null
        ? Get.deviceLocale!.languageCode
        : await localStorage.languageSelected;
     value=  appLocale.value=='ar'?0:1;


    Get.updateLocale(Locale(appLocale.value));

  }

onClickRadio(int value){

  if(value==0) {
    changeLanguage("ar");
    this.value=0;
    Get.updateLocale(Locale(appLocale.value));

  }else{
    changeLanguage("en");
   this.value= 1;
    Get.updateLocale(Locale(appLocale.value));

  }
print(value);
  update();

}
  void changeLanguage(String type) async {
    LocalStorage localStorage = LocalStorage();
    GetStorage().write(AppConstants.changeLang, type==null?Get.deviceLocale!.languageCode:type );
    if (appLocale.value == type) {
      return;
    }
    if (type == AppConstants.ar) {
      appLocale.value = AppConstants.ar;

      localStorage.saveLanguageToDisk(AppConstants.ar);
    } else {
      appLocale.value = AppConstants.en;

      localStorage.saveLanguageToDisk(AppConstants.en);
    }
   // update();
  }

}

