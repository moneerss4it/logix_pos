class SalesPointsModel {
  bool? success;
  List<DataSalesPoints>? data;
  String? message;


  SalesPointsModel({this.success, this.data, this.message,});

  SalesPointsModel.fromJson(Map<String, dynamic> json) {
    success = json['success'];
    if (json['data'] != null) {
      data = <DataSalesPoints>[];
      json['data'].forEach((v) {
        data!.add(new DataSalesPoints.fromJson(v));
      });
    }
    message = json['message'];

  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['success'] = this.success;
    if (this.data != null) {
      data['data'] = this.data!.map((v) => v.toJson()).toList();
    }
    data['message'] = this.message;

    return data;
  }
}

class DataSalesPoints {
  int? id;
  String? name;
  int? customerId;
  int? branchId;
  String? customerName;
  int? inventoryId;
  int? facilityId;
  int? cashAccountId;
  int? bankAccountId;
  int? bankId;
  int? lnkAccounting;
  bool? lnkInventory;
  DataSalesPoints(
      {this.id,
        this.name,
        this.customerId,
        this.branchId,
        this.customerName,
        this.inventoryId,
        this.facilityId,
        this.cashAccountId,
        this.bankAccountId,
        this.lnkAccounting,
        this.lnkInventory,
        this.bankId});

  DataSalesPoints.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    customerId = json['customerId'];
    branchId = json['branchId'];
    customerName = json['customerName'];
    inventoryId = json['inventoryId'];
    facilityId = json['facilityId'];
    cashAccountId = json['cashAccountId'];
    bankAccountId = json['bankAccountId'];
    bankId = json['bankId'];
    lnkAccounting = json['lnkAccounting'];
    lnkInventory = json['lnkInventory'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['customerId'] = this.customerId;
    data['branchId'] = this.branchId;
    data['customerName'] = this.customerName;
    data['inventoryId'] = this.inventoryId;
    data['facilityId'] = this.facilityId;
    data['cashAccountId'] = this.cashAccountId;
    data['bankAccountId'] = this.bankAccountId;
    data['bankId'] = this.bankId;
    data['lnkAccounting'] = this.lnkAccounting;
    data['lnkInventory'] = this.lnkInventory;
    return data;
  }
}
