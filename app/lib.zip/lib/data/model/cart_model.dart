


class CartItem {
  final int id;
   double price;
  final String name;
  final String name2;
  final String unitId;
  final String description;
   int quantity;
  final double discountRate;
  final double discountAmount;
  final double vat;
  final double vatAmount;
  final double total;
  final bool priceIncludeVat;

  CartItem({
    required this.id,
    required this.price,
    required this.name,
    required this.name2,
    required this.unitId,
    required this.description,
    required this.quantity,
    required this.discountRate,
    required this.discountAmount,
    required this.vat,
    required this.vatAmount,
    required this.total,
    required this.priceIncludeVat,
  });

  // Constructor logic to calculate values
  CartItem.calculate({
    required int id,
    required String name,
    required String name2,
    required double price,
    required String unitId,
    required String description,
    required int quantity,
    required double discountRate,
    required double vat,
    required bool priceIncludeVat,
  })  : id = id,
        price = price,
        unitId = unitId,
        name = name,
        priceIncludeVat = priceIncludeVat,
        name2 = name2,
        description = description,
        quantity = quantity,
        discountRate = discountRate,
        discountAmount = (discountRate * quantity),
        vat = vat,
        vatAmount = !priceIncludeVat ?double.parse(( quantity * (price - (discountRate * quantity))*.15).toStringAsFixed(2)): double.parse(((( 100) * (quantity * (price - (discountRate * quantity))))/115*.15).toStringAsFixed(2)),
        total =  double.parse((quantity * (price - (discountRate * quantity))).toStringAsFixed(2))+( !priceIncludeVat ?double.parse(( quantity * (price - (discountRate * quantity))*.15).toStringAsFixed(2)):0);




  // Convert a CartItem object to a map
  Map<String, dynamic> toJson() {
    return {
      "id": id,
      "price": price,
      "name": name,
      "name2": name2,
      "unitId": unitId,
      "description": description,
      "quantity": quantity,
      "discountRate": discountRate,
      "discountAmount": discountAmount,
      "vat": vat,
      "vatAmount": vatAmount,
      "total": total,
      "priceIncludeVat": priceIncludeVat,
    };
  }


  // Convert a JSON map to a CartItem object
  factory CartItem.fromJson(Map<String, dynamic> json) {
    return CartItem(
      id: json['id'],
      price: json['price'],
      name: json['name'],
      name2: json['name2'],
      unitId: json['unitId'],
      description: json['description'],
      quantity: json['quantity'],
      discountRate: json['discountRate'],
      discountAmount: json['discountAmount'],
      vat: json['vat'],
      vatAmount: json['vatAmount'],
      total: json['total'],
      priceIncludeVat: json['priceIncludeVat'],
    );
  }
}

