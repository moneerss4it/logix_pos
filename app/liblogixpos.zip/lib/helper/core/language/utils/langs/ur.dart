const Map<String, String> ur = {

  'Sign in':'سائن آؤٹ کریں',
  'Sign out':'سائن آؤٹ کریں',
  'Username':'صارف کا نام',
  'Do you want to logout':"کیا آپ لاگ آؤٹ کرنا چاہتے ہیں؟",

  'Password':'پاس ورڈ',

  'Choose':'منتخب کریں',
  'Enter the Password' :'پاس ورڈ درج کریں',
  'Enter the Username' :'صارف کا نام درج کریں',
  "Next":"اگلا",
  'Enter the ID member':'رکن کا آئی ڈی درج کریں',

  "Home":"ہوم",
  'Cancel':'منسوخ کریں',
  'Confirm':'تصدیق کریں',

  "Search":"تلاش کریں",

  "ID Member":"رکن کا آئی ڈی",

  "Printer":'پرنٹر',
  "Add": "شامل کریں",
  "Price": "قیمت",
  "Quantity": "مقدار",
  "Add to cart": "ٹوکری میں شامل کریں",
  "Cart": "ٹوکری",
  "Checkout": "ادائیگی مکمل کریں",
  "Payment": "ادائیگی",
  "Total": "کل",
  "Total with VAT": "کل ٹیکس کے ساتھ",
  "Total Amount": "کل رقم",
  "Payment Method": "ادائیگی کا طریقہ",
  "Amount Received": "موصولہ رقم",

  "Payment Success":"ادائیگی کامیاب",
  "Change Point of Sale":"فروخت کا مقام تبدیل کریں",
  "Forgot Your Password?":  "کیا آپ پاس ورڈ بھول گئے ہیں؟",

  "Total Sales":"کل فروخت",
  "Total Sales By Payment":"ادائیگی کے لحاظ سے کل فروخت",
  "Network":"نیٹ ورک",
  "Posting":"پوسٹنگ",
  "Cash":"نقد",
  "Forward":"آگے",
  "Sales Report":"فروخت کی رپورٹ",
  "Unpaid Invoices":"غیر ادا شدہ رسیدیں",
  "Paid Invoices":"ادا شدہ رسیدیں",
  "Invoice ID":'رسید نمبر',
  "Price with VAT": 'قیمت ٹیکس کے ساتھ',
  "VAT": 'ٹیکس',
  "Items": 'اشیاء',
  "Item Name":'شے کا نام',

  "Payment Type": 'ادائیگی کی قسم',
  "Language": 'لغہ',
  "Choose Printer": 'پرنٹر منتخب کریں',
};
