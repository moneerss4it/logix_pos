
class InvoiceModel{
   int no;
   String code;

 InvoiceModel({required this.no,required this.code});
}