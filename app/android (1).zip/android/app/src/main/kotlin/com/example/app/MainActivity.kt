package com.logixerp.logixpos

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
